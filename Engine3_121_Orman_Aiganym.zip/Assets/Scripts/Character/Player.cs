using System.Collections.Generic;
using System.Text.RegularExpressions;
using Unity.VisualScripting;
using UnityEngine;

public class Player : Character
{
    public override Character CharacterTarget
    {
        get
        {
            if (GameManager.Instance == null)
                return null;

            List<Character> list = GameManager.Instance.CharacterFactory.ActiveCharacters;
            if (list == null || list.Count == 0)
                return null;

            Character target = null;
            float minDistance = float.MaxValue;

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] == null)
                    continue;

                if (list[i].CharacterType == CharacterType.Player)
                    continue;

                float distance = Vector3.Distance(list[i].transform.position, transform.position);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    target = list[i];
                }
            }
            return target;
        }
    }

    public override void Initialize()
    {
        base.Initialize();
    }
    public override void Update()
    {
        if (!gameObject.activeInHierarchy)
            return;

        if (MovableComponent == null || AttackComponent == null)
            return;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 move = new Vector3(h, 0, v).normalized;

        Character target = CharacterTarget;

        if (target != null)
        {
            Vector3 dir = target.transform.position - transform.position;
            MovableComponent.Rotation(dir);

            if (Input.GetButtonDown("Jump"))
                AttackComponent.MakeDamage(target);
        }
        else
        {
            MovableComponent.Rotation(move);
        }

        MovableComponent.Move(move);
    }

}
