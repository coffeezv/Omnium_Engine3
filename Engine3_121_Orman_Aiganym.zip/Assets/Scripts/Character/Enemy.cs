using UnityEngine;
public class EnemyCharacter : Character
{
    [SerializeField] private AIState aiState;
    public override Character CharacterTarget => GameManager.Instance.CharacterFactory.Player;
    public override void Initialize()
    {
        base.Initialize();

        HealthComponent = new EnemyHealthComponent();
        AttackComponent = new CharacterAttackComponent();
        AttackComponent.Initialize(characterData);

        aiState = AIState.MoveToTarget;
    }
    
    public override void Update()
    {
        if (CharacterTarget == null)
            return;

        float distance = Vector3.Distance(
            characterData.CharacterTransform.position,
            CharacterTarget.transform.position
        );

        float attackRange = AttackComponent.AttackRange;

        switch (aiState)
        {
            case AIState.None:
                return;

            case AIState.MoveToTarget:
                if (distance <= attackRange)
                {
                    aiState = AIState.Attack;
                    return;
                }

                Move();
                return;

            case AIState.Attack:
                if (distance > attackRange)
                {
                    aiState = AIState.MoveToTarget;
                    return;
                }

                AttackComponent.MakeDamage(CharacterTarget);
                return;
        }
    }

    private void Move()
    {
        Vector3 direction = CharacterTarget.transform.position - characterData.CharacterTransform.position;
        direction = direction.normalized;

        MovableComponent.Move(direction);
        MovableComponent.Rotation(direction);
    }
}