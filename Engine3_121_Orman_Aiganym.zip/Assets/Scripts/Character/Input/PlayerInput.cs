using UnityEngine;

public class PlayerInput : ICharacterInput
{
    public Vector3 MoveDirection =>
        new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

    public bool IsAttack => Input.GetMouseButtonDown(0);
}
