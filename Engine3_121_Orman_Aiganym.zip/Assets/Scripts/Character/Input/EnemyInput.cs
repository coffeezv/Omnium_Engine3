using UnityEngine;

public class AIInput : ICharacterInput
{
    private EnemyCharacter enemy;

    public AIInput(EnemyCharacter enemy)
    {
        this.enemy = enemy;
    }

    public Vector3 MoveDirection => Vector3.zero;
    public bool IsAttack => false;
}
