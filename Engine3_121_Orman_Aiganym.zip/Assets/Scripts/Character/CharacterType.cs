using UnityEngine;

public enum CharacterType
{
    Nobe = 0, 
    Player = 1, 
    DefaultEnemy = 2,
}
