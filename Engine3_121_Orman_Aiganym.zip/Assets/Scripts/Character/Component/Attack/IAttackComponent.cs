public interface IAttackComponent 
{ 
    public float Damage {get;} 
    float AttackRange {get;} 
    public void MakeDamage(Character attackTarget); 
    void Initialize(CharacterData characterData); 
}