using UnityEngine;
public class CharacterAttackComponent : IAttackComponent 
{ 
    private Transform characterTransform;
    private CharacterData characterData; 
    private float lockDamageTime = 0;
    public float Damage => 5; 
    public float AttackRange =>1.3f; 
    
    public void Initialize(CharacterData characterData) 
    { 
        characterTransform = characterData.CharacterTransform;
    } 

    public void MakeDamage(Character attackTarget) 
    { 
        if (attackTarget == null)
            return;

        if (!attackTarget.HealthComponent.IsAlive)
            return;

        if (Vector3.Distance(attackTarget.transform.position, characterTransform.position)> 1.3)
            return;

        if (lockDamageTime > 0)
        {
            lockDamageTime -= Time.deltaTime;
            return;
        }

        attackTarget.HealthComponent.GetDamage(Damage);
        lockDamageTime = 1;
    } 
}