
using System;

public interface IHealthComponent : ICharacterComponent
{
    public event Action<Character> OnCharacterDeath;
    public bool IsAlive {get; }
    public float Health { get; }
    public int MaxHealth { get; }
    public void GetDamage(float damage);
}
