using UnityEngine;

public class CharacterSpawnController : MonoBehaviour
{
    [SerializeField] private CharacterFactory characterFactory;
    [SerializeField] private GameData gameData;

    private float spawnTimer;
    private float gameTime;

    private int currentActiveEnemies;
    private bool isActive;

    public void StartSpawn()
    {
        gameTime = 0f;
        spawnTimer = gameData.TimeBetweenEnemySpawn;
        currentActiveEnemies = 0;
        isActive = true;
    }

    public void StopSpawn()
    {
        isActive = false;
    }

    private void Update()
    {
        if (!isActive)
            return;

        gameTime += Time.deltaTime;
        spawnTimer -= Time.deltaTime;

        if (spawnTimer <= 0f)
        {
            TrySpawnEnemy();
            spawnTimer = gameData.TimeBetweenEnemySpawn;
        }
    }

    private void TrySpawnEnemy()
    {
        int maxEnemies = GetMaxEnemies();

        if (currentActiveEnemies >= maxEnemies)
            return;

        SpawnEnemy();
    }

    private int GetMaxEnemies()
    {
        int minutesPassed = Mathf.FloorToInt(gameTime / 60f);
        return gameData.BaseMaxEnemies + minutesPassed * gameData.EnemiesPerMinute;
    }

    private void SpawnEnemy()
    {
        Character enemy = characterFactory.GetCharacter(CharacterType.DefaultEnemy);

        Vector3 playerPos = characterFactory.Player.transform.position;
        enemy.transform.position = playerPos + GetRandomOffset();

        enemy.gameObject.SetActive(true);
        enemy.Initialize();
        enemy.HealthComponent.OnCharacterDeath += OnEnemyDeath;

        currentActiveEnemies++;
    }

    private void OnEnemyDeath(Character enemy)
    {
        enemy.HealthComponent.OnCharacterDeath -= OnEnemyDeath;
        enemy.gameObject.SetActive(false);

        characterFactory.ReturnCharacter(enemy);
        currentActiveEnemies--;
    }

    private Vector3 GetRandomOffset()
    {
        float x = Random.Range(gameData.MinSpawnOffset, gameData.MaxSpawnOffset);
        float z = Random.Range(gameData.MinSpawnOffset, gameData.MaxSpawnOffset);

        if (Random.value > 0.5f) x *= -1;
        if (Random.value > 0.5f) z *= -1;

        return new Vector3(x, 0, z);
    }
}
