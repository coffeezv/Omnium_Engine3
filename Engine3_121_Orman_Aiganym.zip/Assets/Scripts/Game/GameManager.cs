using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private CharacterFactory characterFactory;
    [SerializeField] private CharacterSpawnController spawnController;
    [SerializeField] private GameData gameData;
    private ScoreSystem scoreSystem;
    private float gameSessionTime;
    private bool isGameActive;
    public static GameManager Instance { get; private set; }
    public CharacterFactory CharacterFactory => characterFactory;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        Initialize();
    }

    private void Initialize()
    {
        scoreSystem = new ScoreSystem();
        isGameActive = false;
    }

    public void StartGame()
    {
        if (isGameActive)
            return;

        Character player = characterFactory.GetCharacter(CharacterType.Player);
        player.transform.position = Vector3.zero;
        player.gameObject.SetActive(true);
        player.Initialize();
        player.HealthComponent.OnCharacterDeath += OnCharacterDeath;

        gameSessionTime = 0f;
        scoreSystem.StartGame();

        spawnController.StartSpawn();

        isGameActive = true;
    }

    private void Update()
    {
        if (!isGameActive)
            return;

        gameSessionTime += Time.deltaTime;

        if (gameSessionTime >= gameData.SessionTimeSeconds)
        {
            GameVictory();
        }
    }

    private void OnCharacterDeath(Character character)
    {
        switch (character.CharacterType)
        {
            case CharacterType.Player:
                GameOver();
                break;

            case CharacterType.DefaultEnemy:
                scoreSystem.AddScore(character.CharacterData.ScoreCost);
                break;
        }

        character.HealthComponent.OnCharacterDeath -= OnCharacterDeath;
        character.gameObject.SetActive(false);
        characterFactory.ReturnCharacter(character);
    }

    private void GameVictory()
    {
        isGameActive = false;

        spawnController.StopSpawn();
        scoreSystem.EndGame();

        Debug.Log("Victory 🎉");
    }

    private void GameOver()
    {
        isGameActive = false;

        spawnController.StopSpawn();
        scoreSystem.EndGame();

        Debug.Log("Defeat 💀");
    }
}
