public interface ICharacterComponent
{
    void Initialize(Character selfCharacter);
    
}