using System;
using UnityEngine;

public class EnemyHealthComponent : IHealthComponent
{
    private Character selfCharacter;
    private float health;
    public bool IsAlive => Health > 0;
    public int MaxHealth => 10;
    public float Health
    {
        get => health;
        private set
        {
            health = value;
            if(health <= 0)
            {
                health = 0;
                OnCharacterDeath?.Invoke(selfCharacter);
            }
        }
    }
    public event Action<Character> OnCharacterDeath;

    public void GetDamage(float damage)
    {
        throw new NotImplementedException();
    }

    public void Initialize(Character selfCharacter)
    {
        this.selfCharacter = selfCharacter;
    }
}
