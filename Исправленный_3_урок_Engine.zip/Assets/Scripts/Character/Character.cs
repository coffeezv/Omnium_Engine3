using UnityEngine;

public abstract class Character : MonoBehaviour 
{ 
    [SerializeField] private CharacterType characterType;
    [SerializeField] protected CharacterData characterData;

    public virtual Character CharacterTarget { get; }
    public CharacterType CharacterType => characterType;
    public CharacterData CharacterData => characterData;

    public IMovable MovableComponent { get; protected set; }
    public IHealthComponent HealthComponent { get; protected set; }
    public IAttackComponent AttackComponent { get; protected set; }

    protected ICharacterInput input;



    public virtual void Initialize()
    {
        MovableComponent = new CharactertMovementComponent();
        MovableComponent.Initialize(characterData);
    } 
    public abstract void Update(); 
    public void Initialize(ICharacterInput input)
    {
        this.input = input;
    }

}