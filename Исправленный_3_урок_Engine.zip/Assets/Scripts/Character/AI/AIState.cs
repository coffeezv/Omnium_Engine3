public enum AIState
{
    None = 0,
    MoveToTarget = 1, 
    Attack
}