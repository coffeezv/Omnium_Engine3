using UnityEngine;

public class CharacterData : MonoBehaviour
{
    [SerializeField] private CharacterController characterController;
    [SerializeField] private Transform characterTransform;
    [SerializeField] private float speed;
    [SerializeField] private int scoreCost;
    [SerializeField] private float timeBetweenAttacks;

    public float DefaultSpeed => speed;
    public int ScoreCost => scoreCost;
    public float TimeBetweenAttacks => timeBetweenAttacks;
    public Transform CharacterTransform => characterTransform;
    public CharacterController CharacterController
    {
        get
        {
            return characterController;
        }
    }
}
